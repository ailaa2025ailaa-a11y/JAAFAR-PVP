package com.jafaar.pvp.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class KitMenuScreen extends Screen {
    public KitMenuScreen() {
        super(Component.literal("JAFAAR PvP - Choose Your Kit"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 100;
        int top = this.height / 2 - 82;
        String[][] kits = {
            {"CRYSTAL", "crystal"}, {"MACE", "mace"}, {"SWORD", "sword"},
            {"AXE", "axe"}, {"SPEAR", "spear"}, {"UHC", "uhc"},
            {"NETHPOT", "nethpot"}
        };
        for (int i = 0; i < kits.length; i++) {
            final String command = kits[i][1];
            int x = left + (i % 2) * 104;
            int y = top + (i / 2) * 24;
            this.addRenderableWidget(Button.builder(Component.literal(kits[i][0]),
                button -> {
                    JafaarPvPClient.runCommand("jafaar kit give " + command);
                    this.onClose();
                }).bounds(x, y, 98, 20).build());
        }
        this.addRenderableWidget(Button.builder(Component.literal("CLOSE"), b -> this.onClose())
            .bounds(left, top + 4 * 24, 202, 20).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, "JAFAAR PvP", this.width / 2, this.height / 2 - 105, 0xE8C547);
        graphics.drawCenteredString(this.font, "Select a kit", this.width / 2, this.height / 2 - 92, 0xFFFFFF);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
