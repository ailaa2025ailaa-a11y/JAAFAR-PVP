package com.jafaar.pvp;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

public class JafaarPvP implements ModInitializer {
    public static final String MOD_ID = "jafaarpvp";

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(Commands.literal("jafaar")
                .then(Commands.literal("help").executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal(
                        "JAFAAR PvP: /jafaar kit list | /jafaar kit give <name> | /jafaar status"
                    ), false);
                    return 1;
                }))
                .then(Commands.literal("status").executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal(
                        "JAFAAR PvP v0.5.0 - Kits module loaded"
                    ), false);
                    return 1;
                }))
                .then(Commands.literal("kit")
                    .then(Commands.literal("list").executes(ctx -> {
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "Kits: crystal, mace, sword, axe, spear, uhc, nethpot"
                        ), false);
                        return 1;
                    }))
                    .then(Commands.literal("give")
                        .then(Commands.argument("kit", net.minecraft.commands.arguments.StringArgumentType.word())
                            .suggests((ctx, builder) -> {
                                for (String kit : KitManager.getKitNames()) builder.suggest(kit);
                                return builder.buildFuture();
                            })
                            .executes(ctx -> KitManager.giveKit(
                                ctx.getSource(),
                                net.minecraft.commands.arguments.StringArgumentType.getString(ctx, "kit")
                            ))
                        )
                    )
                )
            )
        );
    }
}
