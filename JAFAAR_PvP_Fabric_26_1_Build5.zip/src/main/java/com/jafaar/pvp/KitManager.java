package com.jafaar.pvp;

import java.util.List;
import java.util.Locale;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class KitManager {
    private KitManager() {}

    public static List<String> getKitNames() {
        return List.of("crystal", "mace", "sword", "axe", "spear", "uhc", "nethpot");
    }

    public static int giveKit(CommandSourceStack source, String requested) throws Exception {
        ServerPlayer player = source.getPlayerOrException();
        String name = requested.toLowerCase(Locale.ROOT);
        List<ItemStack> kit = switch (name) {
            case "crystal" -> crystal();
            case "mace" -> mace();
            case "sword" -> sword();
            case "axe" -> axe();
            case "spear" -> spear();
            case "uhc" -> uhc();
            case "nethpot" -> nethpot();
            default -> null;
        };
        if (kit == null) {
            source.sendFailure(Component.literal("Unknown kit. Use /jafaar kit list"));
            return 0;
        }

        player.getInventory().clearContent();
        for (ItemStack stack : kit) {
            if (!stack.isEmpty()) player.getInventory().add(stack);
        }
        player.getInventory().setChanged();
        source.sendSuccess(() -> Component.literal("Equipped JAFAAR " + name.toUpperCase(Locale.ROOT) + " kit!"), false);
        return 1;
    }

    private static ItemStack item(Item item, int count) { return new ItemStack(item, count); }

    private static List<ItemStack> crystal() {
        return List.of(
            item(Items.NETHERITE_SWORD, 1), item(Items.OBSIDIAN, 64),
            item(Items.END_CRYSTAL, 64), item(Items.TOTEM_OF_UNDYING, 1),
            item(Items.NETHERITE_CHESTPLATE, 1), item(Items.NETHERITE_LEGGINGS, 1),
            item(Items.NETHERITE_HELMET, 1), item(Items.NETHERITE_BOOTS, 1),
            item(Items.GOLDEN_APPLE, 16), item(Items.EXPERIENCE_BOTTLE, 32)
        );
    }

    private static List<ItemStack> mace() {
        return List.of(
            item(Items.MACE, 1), item(Items.WIND_CHARGE, 64),
            item(Items.ELYTRA, 1), item(Items.FIREWORK_ROCKET, 32),
            item(Items.TOTEM_OF_UNDYING, 2), item(Items.GOLDEN_APPLE, 16),
            item(Items.NETHERITE_HELMET, 1), item(Items.NETHERITE_CHESTPLATE, 1),
            item(Items.NETHERITE_LEGGINGS, 1), item(Items.NETHERITE_BOOTS, 1)
        );
    }

    private static List<ItemStack> sword() {
        return List.of(
            item(Items.NETHERITE_SWORD, 1), item(Items.SHIELD, 1),
            item(Items.GOLDEN_APPLE, 32), item(Items.COBWEB, 16),
            item(Items.WATER_BUCKET, 1), item(Items.LAVA_BUCKET, 1),
            item(Items.TOTEM_OF_UNDYING, 2), item(Items.NETHERITE_CHESTPLATE, 1),
            item(Items.NETHERITE_LEGGINGS, 1), item(Items.NETHERITE_HELMET, 1),
            item(Items.NETHERITE_BOOTS, 1)
        );
    }

    private static List<ItemStack> axe() {
        return List.of(
            item(Items.NETHERITE_AXE, 1), item(Items.SHIELD, 1),
            item(Items.NETHERITE_SWORD, 1), item(Items.GOLDEN_APPLE, 16),
            item(Items.TOTEM_OF_UNDYING, 2), item(Items.COBWEB, 16),
            item(Items.NETHERITE_CHESTPLATE, 1), item(Items.NETHERITE_LEGGINGS, 1),
            item(Items.NETHERITE_HELMET, 1), item(Items.NETHERITE_BOOTS, 1)
        );
    }

    private static List<ItemStack> spear() {
        return List.of(
            item(Items.TRIDENT, 1), item(Items.SHIELD, 1),
            item(Items.NETHERITE_SWORD, 1), item(Items.WIND_CHARGE, 32),
            item(Items.GOLDEN_APPLE, 16), item(Items.TOTEM_OF_UNDYING, 2),
            item(Items.NETHERITE_CHESTPLATE, 1), item(Items.NETHERITE_LEGGINGS, 1),
            item(Items.NETHERITE_HELMET, 1), item(Items.NETHERITE_BOOTS, 1)
        );
    }

    private static List<ItemStack> uhc() {
        return List.of(
            item(Items.DIAMOND_SWORD, 1), item(Items.BOW, 1),
            item(Items.ARROW, 32), item(Items.GOLDEN_APPLE, 8),
            item(Items.WATER_BUCKET, 1), item(Items.LAVA_BUCKET, 1),
            item(Items.COBBLESTONE, 64), item(Items.CRAFTING_TABLE, 1),
            item(Items.FURNACE, 1), item(Items.IRON_PICKAXE, 1),
            item(Items.DIAMOND_CHESTPLATE, 1), item(Items.DIAMOND_LEGGINGS, 1),
            item(Items.DIAMOND_HELMET, 1), item(Items.DIAMOND_BOOTS, 1)
        );
    }

    private static List<ItemStack> nethpot() {
        return List.of(
            item(Items.NETHERITE_SWORD, 1), item(Items.SPLASH_POTION, 16),
            item(Items.POTION, 8), item(Items.GOLDEN_APPLE, 16),
            item(Items.OBSIDIAN, 32), item(Items.END_CRYSTAL, 32),
            item(Items.TOTEM_OF_UNDYING, 2), item(Items.NETHERITE_CHESTPLATE, 1),
            item(Items.NETHERITE_LEGGINGS, 1), item(Items.NETHERITE_HELMET, 1),
            item(Items.NETHERITE_BOOTS, 1)
        );
    }
}
