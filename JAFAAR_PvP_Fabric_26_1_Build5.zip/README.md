# JAFAAR PvP — Build 5 (0.5.0)

Minecraft Java 26.1 / Fabric source project.

## New in Build 5
- Seven selectable practice kits: Crystal, Mace, Sword, Axe, Spear, UHC, NethPot.
- Kit loadouts are granted server-side with `/jafaar kit give <name>`.
- Kit selection screen opens with **Right Shift** and sends the kit command.
- `/jafaar kit list`, `/jafaar help`, `/jafaar status`.
- GitHub Actions workflow builds the JAR and uploads it as an artifact.

## Important
This is a source project, not a prebuilt JAR. It has not been compiled or tested in Minecraft in this environment. Minecraft 26.1 mappings/API can change; if GitHub Actions reports a compile error, share the complete log so the source can be corrected.

Giving a kit clears the player's inventory first. Test in a new test world and back up important worlds. The kit items are currently basic loadouts; custom enchantments, potion effects, armor trim, and per-kit saved inventory layouts are not implemented yet.

## Build
Run `gradle build` with Java 25, or push the project to GitHub and run the Actions workflow.
